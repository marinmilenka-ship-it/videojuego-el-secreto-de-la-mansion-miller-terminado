from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
from ursina import load_texture

#VARIABLES
cronometro_texto = Text(text='01:00',position=(0, 0.45),origin=(0, 0),scale=2,color=color.white,background=True)
cronometro_texto.disable()
fondo_game_over = Entity(parent=camera.ui, model='quad', color=color.rgba(0, 0, 0, 220), scale=(2, 1.5), z=-0.2, enabled=False)
texto_game_over = Text(parent=camera.ui, text="", scale=2, origin=(0, 0), position=(0, 0.2), color=color.red, z=-0.3, enabled=False)
app = Ursina()
camera.clip_plane_near = 0.09
window.fps_counter.enabled = False
window.exit_button.visible = False
tiempo_restante = 1 * 60  
intro_terminada = False
game_over_activo = False   
vidas = 3
# ADAPTADO AL CÓDIGO 2: La posición cambia para estar dentro de la sala
checkpoint_pos = Vec3(0, 2, -8)

# ============================================================
# DISEÑOS 3D - DISTRIBUCIÓN DENTRO DE sala1.glb
#
# La sala1.glb se escala a 0.1 y gira 180 grados. La geometría
# de la sala queda aproximadamente entre x/z = -200 y +200.
#
# Distribución buscada:
#   - PUERTA: pared izquierda, para abrir y salir al siguiente nivel.
#   - VENTANA ROTA: pared derecha, en el lado opuesto a la puerta.
#   - RELOJ: centro de la pared del fondo, pegado a la pared.
#   - CUADRO OP ART: a la derecha del reloj.
#   - CUADRO 2: más a la derecha del Op Art.
#
# IMPORTANTE: estos objetos son decorativos y NO siguen a la cámara.
# Solo la puerta tiene animación cuando se pulsa E.
# ============================================================

ASSET_VENTANA = 'Broken window by Justin Randall - a_Q2-bs4zu9.glb'
ASSET_RELOJ = 'Clock by Poly by Google - dwZRvbXlAus.glb'
ASSET_PUERTA = 'Door by Quaternius - atrxVW0q9N.glb'
ASSET_CUADRO_OP = 'Op Art by Ryan Murray - 1d1jTNZHwAS.glb'
ASSET_CUADRO1 = 'Cuadro1.glb'
ASSET_CUADRO2 = 'Cuadro2.glb'

# Coordenadas WORLD de la sala.
# Las paredes laterales están aproximadamente en x = +/- 200
# y la pared del fondo está aproximadamente en z = -200.
POS_PUERTA = Vec3(-198.0, 0.0, 0.0)
POS_VENTANA = Vec3(198.0, 3.0, 0.0)
POS_RELOJ = Vec3(0.0, 4.0, -198.0)
POS_CUADRO_OP = Vec3(5.0, 4.0, -197.7)
POS_CUADRO1 = Vec3(9.5, 4.0, -197.7)
POS_CUADRO2 = Vec3(13.5, 4.0, -197.7)

class Disenos3D:
    """Coloca los diseños 3D directamente sobre las paredes de sala1."""

    def __init__(self):
        self.elementos = []

        # --------------------------------------------------------
        # PUERTA - PARED IZQUIERDA
        # --------------------------------------------------------
        # El pivot queda fijo en la pared. El modelo gira alrededor
        # de ese pivot únicamente al pulsar E.
        self.puerta_pivot = Entity(
            position=POS_PUERTA,
            rotation=(0, 90, 0),
            name='puerta_pivot'
        )

        self.puerta = Entity(
            parent=self.puerta_pivot,
            model=ASSET_PUERTA,
            position=(0, 0, 0),
            rotation=(0, 0, 0),
            scale=0.70,
            collider='box',
            name='Puerta'
        )
        self.puerta.interactuable = True
        self.puerta.tipo_interaccion = 'puerta'
        self.puerta.abierta = False
        self.elementos.append(self.puerta)

        # --------------------------------------------------------
        # VENTANA ROTA - PARED DERECHA
        # --------------------------------------------------------
        # Queda en la pared opuesta a la puerta.
        self.ventana = Entity(
            model=ASSET_VENTANA,
            position=POS_VENTANA,
            rotation=(0, -90, 0),
            scale=4.0,
            collider='box',
            name='VentanaRota'
        )
        self.ventana.interactuable = True
        self.ventana.tipo_interaccion = 'ventana'
        self.elementos.append(self.ventana)

        # --------------------------------------------------------
        # RELOJ - CENTRO DE LA PARED DEL FONDO
        # --------------------------------------------------------
        # El modelo del reloj viene con dimensiones enormes.
        # 0.0025 lo deja en un tamaño de reloj de pared.
        # z=-198 lo deja CONTRA la pared, no flotando en medio.
        self.reloj = Entity(
            model=ASSET_RELOJ,
            position=POS_RELOJ,
            rotation=(90, 0, 0),
            scale=0.0025,
            collider=None,
            name='Reloj'
        )
        self.reloj.interactuable = False
        self.elementos.append(self.reloj)

        # --------------------------------------------------------
        # CUADRO OP ART - UN POCO A LA DERECHA DEL RELOJ
        # --------------------------------------------------------
        self.cuadro_op = Entity(
            model=ASSET_CUADRO_OP,
            position=POS_CUADRO_OP,
            rotation=(0, 0, 0),
            scale=0.55,
            collider=None,
            double_sided=True,
            name='CuadroOpArt'
        )
        self.cuadro_op.interactuable = False
        self.elementos.append(self.cuadro_op)

        # --------------------------------------------------------
        # CUADRO 1 - A LA DERECHA DEL OP ART
        # --------------------------------------------------------
        self.cuadro1 = Entity(
            model=ASSET_CUADRO1,
            position=POS_CUADRO1,
            rotation=(0, 0, 0),
            scale=2.2,
            collider=None,
            double_sided=True,
            name='Cuadro1'
        )
        self.cuadro1.interactuable = False
        self.elementos.append(self.cuadro1)

        # --------------------------------------------------------
        # CUADRO 2 - MÁS A LA DERECHA
        # --------------------------------------------------------
        self.cuadro2 = Entity(
            model=ASSET_CUADRO2,
            position=POS_CUADRO2,
            rotation=(0, 0, 0),
            scale=2.2,
            collider=None,
            double_sided=True,
            name='Cuadro2'
        )
        self.cuadro2.interactuable = False
        self.elementos.append(self.cuadro2)

    def interactuar(self, objeto):
        if objeto is self.puerta:
            if not self.puerta.abierta:
                self.puerta_pivot.animate(
                    'rotation_y',
                    self.puerta_pivot.rotation_y + 90,
                    duration=0.6
                )
                self.puerta.abierta = True
                return "Puerta abierta. Puedes pasar al siguiente nivel."
            else:
                self.puerta_pivot.animate(
                    'rotation_y',
                    self.puerta_pivot.rotation_y - 90,
                    duration=0.6
                )
                self.puerta.abierta = False
                return "Puerta cerrada."

        if objeto is self.ventana:
            return "Es una ventana rota."

        return ""


#CLASES Y FUNCIONES
class Mundo:
    def __init__(self):
        # ADAPTADO AL CÓDIGO 2: Sala importada desde Blender
        self.sala = Entity(
            model='sala1.glb',
            position=(0, 0, 0),
            rotation=(0, 180, 0),
            scale=(0.1, 0.1, 0.1),
            collider=None,
            double_sided=True
        )

        # Piso invisible para evitar caídas.
        self.suelo = Entity(
            model='plane',
            scale=(500, 1, 500),
            position=(0, -0.05, 0),
            visible=False,
            collider='box'
        )

        # --------------------------------------------------------
        # PAREDES INVISIBLES DE COLISIÓN
        #
        # Se usan en lugar del collider de sala1.glb para dejar un
        # HUECO REAL en la pared izquierda donde está la puerta.
        # Así, cuando la puerta se abre, el jugador puede atravesarla.
        # --------------------------------------------------------
        self.paredes = []

        # Pared del fondo
        self.paredes.append(Entity(
            model='cube',
            position=(0, 25, -200),
            scale=(400, 50, 1),
            visible=False,
            collider='box'
        ))

        # Pared del frente
        self.paredes.append(Entity(
            model='cube',
            position=(0, 25, 200),
            scale=(400, 50, 1),
            visible=False,
            collider='box'
        ))

        # Pared derecha completa
        self.paredes.append(Entity(
            model='cube',
            position=(200, 25, 0),
            scale=(1, 50, 400),
            visible=False,
            collider='box'
        ))

        # Pared izquierda con HUECO para la puerta.
        # La puerta está alrededor de z=0.
        self.paredes.append(Entity(
            model='cube',
            position=(-200, 25, -101),
            scale=(1, 50, 198),
            visible=False,
            collider='box'
        ))
        self.paredes.append(Entity(
            model='cube',
            position=(-200, 25, 101),
            scale=(1, 50, 198),
            visible=False,
            collider='box'
        ))

class InventarioUI:
    def __init__(self):
        self.slot1 = None
        self.barra = Entity(parent=camera.ui, model='quad', color=color.rgba(0, 0, 0, 150), scale=(0.25, 0.08), position=(0, -0.42),enabled=False)
        self.cuadro = Entity(parent=camera.ui, model='quad', color=color.rgba(50, 50, 50, 255), scale=(0.04, 0.04), position=(-0.08, -0.42),enabled=False)
        self.texto = Text(parent=camera.ui, text="1: [ Vacio ]", position=(-0.04, -0.42), scale=1.5, color=color.light_gray,enabled=False)
        self.objeto_mano = Entity(parent=camera, model='cube', color=color.yellow, scale=(0.1, 0.1, 0.4), position=(0.35, -0.25, 0.6), enabled=False)

    def activar(self):
        self.barra.enabled = True
        self.cuadro.enabled = True
        self.texto.enabled = True

    def guardar_objeto(self, nombre):
        self.slot1 = nombre
        self.texto.text = f"1: {nombre}"
        self.texto.color = color.yellow
        self.cuadro.color = color.yellow

    def vaciar_slot(self):
        self.slot1 = None
        self.objeto_mano.enabled = False
        self.texto.text = "1: [ Vacio ]"
        self.texto.color = color.light_gray
        self.cuadro.color = color.rgba(50, 50, 50, 255)

    def alternar_equipado(self):
        if self.slot1:
            self.objeto_mano.enabled = not self.objeto_mano.enabled

class ObjetoLanzable(Entity):
    def __init__(self, posicion, direccion, nombre, jugador_ref):
        super().__init__(model='cube', color=color.yellow, scale=(0.5, 0.5, 0.5), position=posicion,name=nombre)
        self.agarrable = True
        self.direccion = direccion
        self.fuerza_lanzamiento = 25
        self.velocidad_y = 8
        self.jugador_ref = jugador_ref

    def update(self):
        if self.fuerza_lanzamiento > 0 or self.y > 0.25:
            self.velocidad_y -= time.dt * 15
            desplazamiento = (self.direccion * self.fuerza_lanzamiento + Vec3(0, self.velocidad_y, 0)) * time.dt           
            hit_info = raycast(self.world_position, desplazamiento.normalized(), distance=0.6, ignore=(self, self.jugador_ref))    
            if hit_info.hit:
                self.fuerza_lanzamiento = 0
                self.velocidad_y = -2 
            else:
                self.position += desplazamiento
            if self.y <= 0.25:
                self.y = 0.25
                self.fuerza_lanzamiento = 0
                self.velocidad_y = 0
                self.collider = 'box' 

class Jugador(FirstPersonController):
    def __init__(self, inventario_ui, mundo_ref):
        super().__init__(position=(0, 2, -8)) # ADAPTADO AL CÓDIGO 2
        self.collider = 'box'
        self.enabled = False 
        self.ui = inventario_ui
        self.mundo = mundo_ref
        self.vel_normal = 5
        self.vel_correr = 8
        self.vel_sigilo = 2.5
        self.altura_normal = self.camera_pivot.y
        self.altura_agachado = 1.0
        self.speed = self.vel_normal
        self.jump_height = 2               
        self.jump_up_duration = 0.4    
        self.gravity = 1               
        self.audio_pasos = Audio('pasos.mp3', autoplay=False, loop=True, volume=1) # DEL CÓDIGO 1

    # DEL CÓDIGO 1
    def update(self):
        super().update()
        moviendose = held_keys['w'] or held_keys['a'] or held_keys['s'] or held_keys['d']
        if moviendose and self.grounded:
            if not self.audio_pasos.playing:
                self.audio_pasos.play()
        else:
            if self.audio_pasos.playing:
                self.audio_pasos.stop()

    def input(self, key):
        if key == 'escape': application.quit()
        if not self.enabled: return
        super().input(key)
        if key == 'e':
            hit_info = boxcast(
                camera.world_position,
                direction=camera.forward,
                distance=4.5,
                thickness=(0.5, 0.5),
                ignore=(self, *self.mundo.paredes)
            )
            if hit_info.hit:
                obj = hit_info.entity

                # Primero se prueban los diseños 3D.
                if hasattr(obj, 'interactuable'):
                    mensaje = disenos.interactuar(obj)
                    if mensaje:
                        print(mensaje)
                    return

                # Después se mantiene el sistema de objetos del juego.
                if hasattr(obj, 'agarrable'):
                    self.ui.guardar_objeto(obj.name)
                    destroy(obj)
        if key == '1':
            self.ui.alternar_equipado()
        if key == 'left mouse down' and self.ui.objeto_mano.enabled:
            ObjetoLanzable(posicion=camera.world_position + camera.forward, direccion=camera.forward, nombre=self.ui.slot1,jugador_ref=self)
            self.ui.vaciar_slot()
        if key == 'shift': self.speed = self.vel_correr
        if key == 'shift up': self.speed = self.vel_normal
        if key == 'c':
            self.speed = self.vel_sigilo
            self.camera_pivot.y = self.altura_agachado
        if key == 'c up':
            self.speed = self.vel_normal
            self.camera_pivot.y = self.altura_normal

class Introduccion:
    def __init__(self, jugador_ref):
        self.jugador = jugador_ref
        self.pantalla = Entity(parent=camera.ui, model='quad', color=color.black, scale=(2, 2), z=2, enabled=False)
        mensaje = "Oficial, necesitamos que investigue\nla mansión Miller\npor casos de personas desaparecidas."
        self.texto = Text(text=mensaje, position=(0, 0), origin=(0, 0), scale=2, color=color.white, alpha=0, z=1)
        self.audio_voz = Audio('voz_intro.mp3', autoplay=False, loop=False) # DEL CÓDIGO 1

    def iniciar(self):
        self.pantalla.enabled = True
        self.audio_voz.play() # DEL CÓDIGO 1
        invoke(self.aparecer_texto, delay=1.0)

    def aparecer_texto(self):
        self.texto.fade_in(duration=4.0)
        invoke(self.desaparecer_texto, delay=5.0)

    def desaparecer_texto(self):
        self.texto.fade_out(duration=2.0)
        invoke(self.finalizar, delay=2.5)

    def finalizar(self):
        global intro_terminada     
        intro_terminada = True
        self.pantalla.fade_out(duration=3.5)
        self.jugador.enable()
        self.jugador.ui.activar()
        musica_fondo.play() # DEL CÓDIGO 1

class Menu:
    def __init__(self, intro_ref):
        self.intro=intro_ref
        # ADAPTADO AL CÓDIGO 2: textura="fondo_original.jpg (1).jpeg"
        self.fondo_menu= Entity(parent=camera.ui, model='quad',texture="fondo_original.jpg (1).jpeg",color=color.white,scale=(2,1.5))
        self.titulo=Text(parent=camera.ui, text="La Mansión Miller",scale=3,origin=(0,0), position=(0,0.3), color=color.red,z=-0.1)
        self.boton_play=Button(parent=camera.ui, text="PLAY", scale=(0.3,0.1), position=(0,-0.1),color=color.black,z=-0.1)
        self.boton_play.on_click= self.click_play
    
    def click_play(self):
        destroy(self.titulo)
        destroy(self.boton_play)
        destroy(self.fondo_menu)
        self.intro.iniciar()

def update():
    global tiempo_restante, intro_terminada,game_over_activo, vidas
    if game_over_activo:
        return
    if intro_terminada and tiempo_restante > 0:
        cronometro_texto.enable() 
        tiempo_restante -= time.dt 
        minutos = int(tiempo_restante // 60)
        segundos = int(tiempo_restante % 60)
        cronometro_texto.text = f"{minutos:02d}:{segundos:02d}"
        if tiempo_restante <= 0:
            cronometro_texto.text = "00:00"
            cronometro_texto.color = color.red
            game_over_activo = True
            protagonista.disable()  
            mouse.locked = False
            musica_fondo.stop() # DEL CÓDIGO 1
            mouse.visible = True
            fondo_game_over.enabled = True
            texto_game_over.enabled = True
            if vidas > 1:
                texto_game_over.text = f"GAME OVER\n¿Quieres intentar de vuelta?\n(Te quedarán {vidas - 1} vidas)"
                boton_si.enabled = True
                boton_no.enabled = True
            else:
                texto_game_over.text = "GAME OVER\nJuego Finalizado"

def click_si():
    global vidas, tiempo_restante, game_over_activo
    vidas -= 1               
    tiempo_restante = 1 * 60
    fondo_game_over.enabled = False
    texto_game_over.enabled = False
    boton_si.enabled = False
    boton_no.enabled = False
    protagonista.position = checkpoint_pos
    protagonista.enable()
    mouse.locked = True
    mouse.visible = False
    game_over_activo = False
    musica_fondo.play() # DEL CÓDIGO 1

def click_no():
    boton_si.enabled = False
    boton_no.enabled = False
    texto_game_over.text = "Juego Finalizado"
    application.quit() # DEL CÓDIGO 1

boton_si = Button(parent=camera.ui, text="SÍ", scale=(0.2, 0.08), position=(-0.15, -0.1), color=color.black, z=-0.3, enabled=False)
boton_no = Button(parent=camera.ui, text="NO", scale=(0.2, 0.08), position=(0.15, -0.1), color=color.black, z=-0.3, enabled=False)
boton_si.on_click = click_si
boton_no.on_click = click_no

# INICIALIZACIÓN PRINCIPAL
escenario = Mundo()
disenos = Disenos3D()
interfaz = InventarioUI()
protagonista = Jugador(interfaz, escenario)
mano = Entity(model="protagonista.obj", texture='textura_policia.png',parent=camera,position=(0.5, -0.3, 0.7),rotation=(0, 0, 0),scale=0.1,color=color.white)
mano.disable_shadows=True
intro = Introduccion(protagonista)
menu=Menu(intro)
musica_fondo = Audio('musica_juego.mp3', autoplay=False, loop=True, volume=0.4) # DEL CÓDIGO 1
app.run()